import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;

class SearchMap extends StatefulWidget {
  @override
  State<SearchMap> createState() => SearchMapState();
  const SearchMap({Key? key}) : super(key: key);
}

class SearchMapState extends State<SearchMap> {
  final List<Marker> _markers = [];

  Future<void> _fetchEvents() async {
    final response = await http.get(Uri.parse("http://localhost:3000/events"));
    List<dynamic> events = jsonDecode(response.body);

    for (var e in events) {
      setState(() {
        _markers.add(
          Marker(
            //https://medium.com/flutter-community/add-a-custom-info-window-to-your-google-map-pins-in-flutter-2e96fdca211a
            infoWindow: InfoWindow(title: e['name']),
            markerId: MarkerId(e["id"].toString()),
            position: LatLng(
              e['location']['latitude'],
              e['location']['longitude'],
            ),
          ),
        );
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchEvents();
  }

  @override
  Widget build(BuildContext context) {
    return GoogleMap(
      markers: Set<Marker>.of(_markers),
      mapType: MapType.normal,
      // gestureRecognizers: {
      //   Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer())
      // },
      initialCameraPosition: const CameraPosition(
        target: LatLng(-23.168630524718026, -46.868967544506795),
        zoom: 13,
      ),
    );
  }
}
