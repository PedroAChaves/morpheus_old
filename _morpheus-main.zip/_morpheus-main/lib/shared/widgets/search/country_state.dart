class CountryState {
  final String name;
  final String code;

  CountryState(this.name, this.code);
}
