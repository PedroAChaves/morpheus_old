// import 'package:flutter/material.dart';

// import '../../themes/app_colors.dart';

// class TextField extends StatefulWidget {
//   const TextField({Key? key}) : super(key: key);

//   @override
//   State<TextField> createState() => _TextFieldState();
// }

// class _TextFieldState extends State<TextField> {
//   @override
//   Widget build(BuildContext context) {
//     return TextField(
//       // cursorColor: AppColors.primary,
//       decoration: InputDecoration(
//         focusedBorder: OutlineInputBorder(
//           borderSide: BorderSide(color: AppColors.primary, width: 2),
//         ),
//         border: const OutlineInputBorder(),
//         labelText: 'Email',
//         floatingLabelStyle: TextStyle(color: AppColors.primary),
//         fillColor: Colors.white,
//         filled: true,
//       ),
//     );
//   }
// }
