class AppImages {
  static const logoMorpheus = "images/logo.png";
  static const text = "images/text.png";
  static const backgroundLogin = "images/BackgroundLogin.png";

  static const logo = "images/logo_only.png";
  static const title = "images/title.png";
  static const logoTitle = "images/logo_only.png";
}
