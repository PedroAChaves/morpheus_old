class ApiRoutes {
  static String asdf() {
    return "";
  }
}
