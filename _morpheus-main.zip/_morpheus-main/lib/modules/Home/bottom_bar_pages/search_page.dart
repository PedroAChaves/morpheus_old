import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:morpheus/shared/functions/get_geo_position.dart';
import 'package:morpheus/shared/themes/app_colors.dart';
import 'package:morpheus/shared/widgets/search/country_state.dart';
import 'package:morpheus/shared/widgets/search/see_events_button.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final List<CountryState> _states = [];
  String _selectedState = "SP";
  late LatLng _currentPosition;
  bool _hasSelectedEvent = true;

  Future<void> _fetchStates() async {
    final response = await http.get(
      Uri.parse(
        "https://api.countrystatecity.in/v1/countries/BR/states",
      ),
      headers: {
        "X-CSCAPI-KEY": dotenv.get('COUNTRY_STATE_CITY_API_KEY'),
        'Content-type': 'application/json',
        'Accept': 'application/json',
      },
    );

    final List<dynamic> data = jsonDecode(response.body);
    for (var element in data) {
      setState(() {
        _states.add(
          CountryState(element['name'], element['iso2']),
        );
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchStates();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      body: Column(
        children: [
          Container(
              color: AppColors.primary,
              height: _hasSelectedEvent
                  ? MediaQuery.of(context).size.height * 0.50
                  : MediaQuery.of(context).size.height * 0.56,
              width: double.infinity,
              child: const Text(
                'Vai ve nada',
                style: TextStyle(color: Colors.white, fontSize: 50),
              )
              // const SearchMap(),
              ),
          Expanded(
            child: _hasSelectedEvent
                ? Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: 12,
                      horizontal: 20,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Image.network(
                              "https://live.staticflickr.com/65535/51895923084_21c34b1162_o.jpg",
                              fit: BoxFit.fill,
                              width: 300,
                              height: 140,
                            ),
                            IconButton(
                              onPressed: () => setState(() {
                                _hasSelectedEvent = false;
                              }),
                              icon: const Icon(Icons.close),
                              color: AppColors.primary,
                              iconSize: 34,
                            ),
                          ],
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: const [
                              Text(
                                "Henrique e Juliano",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                "02 de Abril",
                                style: TextStyle(fontSize: 18),
                              ),
                              Text(
                                "HJ Eventos",
                                style: TextStyle(fontSize: 18),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              onPressed: () {},
                              iconSize: 36,
                              icon: const Icon(
                                Icons.star_border,
                                color: AppColors.accent,
                              ),
                            ),
                            TextButton(
                              onPressed: () {},
                              child: Container(
                                color: AppColors.accent,
                                padding: const EdgeInsets.all(6),
                                child: const Text(
                                  "Comprar ingressos",
                                  style: TextStyle(
                                    fontSize: 30,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            )
                          ],
                        )
                      ],
                    ))
                : Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        const Text(
                          'Explore eventos perto de você',
                          overflow: TextOverflow.fade,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: 'Nunito',
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            color: Colors.black,
                          ),
                        ),
                        const Text(
                          'Encontre facilmente eventos ao seu redor, usar o mapa requer o uso da localização',
                          overflow: TextOverflow.fade,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: 'Nunito',
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Color(0xff746565),
                          ),
                        ),
                        SeeEventsButton(
                          icon: const Icon(
                            Icons.my_location_rounded,
                            color: Colors.white,
                          ),
                          text: const Text(
                            "Ver eventos perto de mim",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                          onPress: () async {
                            Position position = await getCurrentPosition();
                            setState(() {
                              _hasSelectedEvent = true;
                              _currentPosition = LatLng(
                                position.latitude,
                                position.longitude,
                              );
                            });
                            print(_currentPosition);
                          },
                        ),
                        DropdownButton<String>(
                          icon: const Icon(Icons.arrow_downward),
                          menuMaxHeight: 400,
                          value: _selectedState,
                          isExpanded: true,
                          elevation: 16,
                          style: const TextStyle(
                            color: AppColors.primary,
                            fontSize: 18,
                          ),
                          underline: Container(
                            height: 2,
                            color: AppColors.primary,
                          ),
                          onChanged: (String? newValue) {
                            setState(() => _selectedState = newValue!);
                            print(_selectedState);
                          },
                          items: _states.map((state) {
                            return DropdownMenuItem(
                              child: Text(state.name),
                              value: state.code,
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
          )
        ],
      ),
    );
  }
}
