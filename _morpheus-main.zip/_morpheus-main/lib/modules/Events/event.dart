import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final dynamic event;
  const DetailScreen({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          Navigator.pop(context);
        },
        child: Center(
          child: Column(
            children: [
              Hero(
                tag: event['id'].toString(),
                child: Image.network(
                  event['cover_url'],
                ),
              ),
              Text(event['id'].toString()),
              Text(event['name']),
              Text(event['organizer_name']),
            ],
          ),
        ),
      ),
    );
  }
}
